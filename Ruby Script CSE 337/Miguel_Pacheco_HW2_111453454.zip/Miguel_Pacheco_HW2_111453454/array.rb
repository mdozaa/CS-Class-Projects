#Miguel Pacheco
# 111453454
# CSE337
# HW2

class Array
  def [](index, length = nil)
    #looking at 3 different possible calls:
    # array[x, y]
    # array[x]
    # array[x..y]

    #Case: array[x, y]
    #check for existence of length parameter; default - nil
    if length != nil

      #checks to see if the index provided is in bounds; otherwise, return the string
      if (index).abs > self.length-1
        '\'\\0\''
      else

        #the positive index. Index stays as is if it is already positive, otherwise it will be found
        posIndex = index
        #lets find the positive index (in the case that it the one provided is negative)
        if index < 0
          posIndex = self.length + index
        end

        #counterMax = length; counter cannot surpass this amount
        counter = 1
        counterMax = Integer(length)

        #this is where we put the elements iterated over
        returnThis = []


        #loop dependant on counter and if it has reached the maximum allowed number
        while counter <= counterMax
          returnThis << self.at(posIndex)
          counter += 1
          #use posIndex and update in order to access the element at a given index
          posIndex += 1
        end

        #return the array that contains all the numbers we went over
        returnThis
      end


    else
      #in the case that length is null (only one argument given)
      # There are two possibilities:
      # index is a Range array[x..y]
      # index is a number array[x]

      #Case: array[x..y]
      if index.class == Range
        #get the index number we are starting from
        firstIndex = index.first
        #get the index number that we are ending on
        maxIndex = index.last

        #x is the iterator variable; assign firstIndex to it (that is where we will start from)
        x = firstIndex
        #where we will put all the stuff that was iterated over
        accountedfor = []

        #while iterator variable is less than or equal to the ending index, get the element at index x
        while x <= maxIndex
          accountedfor << self.at(x)
          #update x to get next position
          x += 1
        end

        #return they array that contains all numbers iterated over
        accountedfor
      else

        #Case: array[x]
        # two sub-cases: positive or negative
        # in either case, the positive or negative number cannot be greater or less than (respectively)
        # than the length of the given array.
        if (index).abs > self.length-1
          '\'\\0\''
          #string above replaces the nil value that would usually be passed instead
        else
          #normal getter.
          self.at(index)
        end

      end
    end
  end

  def map(rangeToChange = nil)
    #check for existence of a range being passed
    if rangeToChange != nil
      #there is a range for affected indexes
      startingIndex = rangeToChange.first
      endingIndex = rangeToChange.last

      modifiedArray = []
      while startingIndex <= endingIndex && startingIndex <= self.length-1
        modifiedArray << yield(self[startingIndex])
        startingIndex += 1
      end

      modifiedArray
    else

      #if no range was passed, then that means the entire array is affected
      counter = 0
      lastIndex = self.length-1

      modifiedArray2 = []
      while counter <= lastIndex
        modifiedArray2 << yield(self[counter])
        counter += 1
      end

      modifiedArray2
    end
  end
end

a = [1,2,3,4,5]
puts a[1]
puts a[10]
puts a.map(2..4) {|i| i.to_f}