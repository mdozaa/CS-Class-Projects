#Miguel Pacheco
# 111453454
# CSE337
# HW2


class Console
  def initialize(player, narrator)
    @player   = player
    @narrator = narrator
  end

  def show_room_description
    @narrator.say "-----------------------------------------"
    @narrator.say "You are in room #{@player.room.number}."

    @player.explore_room

    @narrator.say "Exits go to: #{@player.room.exits.join(', ')}"
  end

  def ask_player_to_act
    actions = {"m" => :move, "s" => :shoot, "i" => :inspect }

    accepting_player_input do |command, room_number|
      @player.act(actions[command], @player.room.neighbor(room_number))
    end
  end

  private

  def accepting_player_input
    @narrator.say "-----------------------------------------"
    command = @narrator.ask("What do you want to do? (m)ove or (s)hoot?")

    unless ["m","s"].include?(command)
      @narrator.say "INVALID ACTION! TRY AGAIN!"
      return
    end

    dest = @narrator.ask("Where?").to_i

    unless @player.room.exits.include?(dest)
      @narrator.say "THERE IS NO PATH TO THAT ROOM! TRY AGAIN!"
      return
    end

    yield(command, dest)
  end
end

class Narrator
  def say(message)
    $stdout.puts message
  end

  def ask(question)
    print "#{question} "
    $stdin.gets.chomp
  end

  def tell_story
    yield until finished?

    say "-----------------------------------------"
    describe_ending
  end

  def finish_story(message)
    @ending_message = message
  end

  def finished?
    !!@ending_message
  end

  def describe_ending
    say @ending_message
  end
end

class Room


  def initialize(roomNumber)
    @number = Integer(roomNumber)
    @hazards = []
    @exit_numbers = []
    @exitRooms = []
  end

  def exits
    #exits works as an accessor for @exit_numbers (an array of the INTEGER number of the room)
    @exit_numbers
  end

  def neighbors
    #neighbors works as an accessor for @exitRooms (an array of ROOM objects)
    @exitRooms
  end

  def connect(room)
    @exit_numbers.append(room.number)
    room.exit_numbers.append(self.number)
    @exitRooms.append(room)
    room.exitRooms.append(self)
  end

  def neighbor(number)
    #exit_numbers and exitRooms elements correspond to one another at the same index
    exitIndex = @exit_numbers.index(number)
    @exitRooms[exitIndex]
  end

  def random_neighbor
    #Get random num between 0 and 2 (inclusive) and pick the neighbor at that index
    self.neighbor(@exit_numbers.at(rand(0..2)))
  end

  def add(hazard)
    #add a hazard to the list
    @hazards.append(hazard)
  end

  def remove(hazard)
    #remove the first instance of hazard in the room (there could be multiple)
    @hazards.delete_at(Integer(@hazards.index(String(hazard))))
  end

  def empty?
    #a room is empty if there are no hazards present; if no hazards are present, then the array must be empty
    if @hazards.length > 0
      false
    else
      true
    end
  end

  def safe?
    #add code that would depict this room as SAFE:
    # no hazards in this room
    # no hazards in neighboring rooms

    #checks each neighboring room for hazards
    safe_outside = true
    @exitRooms.each do |room|
      if room.empty? == false
        safe_outside = false
      end
    end

    #if this room has no hazards, and the neighboring rooms dont either, then return true; it is safe.
    if self.empty? == true && safe_outside
      true
    else
      false
    end
  end

  def has?(hazard)
    #checks the room for a specific hazard
    if @hazards.any?(String(hazard))
      true
    else
      false
    end
  end

  attr_reader :left, :middle, :right, :number, :hazards, :exit_numbers, :exitRooms
  attr_writer :number, :exit_numbers, :exitRooms

end

class Cave
  @@roomlist = []
  attr_accessor :roomlist
  attr_writer :roomlist

  def self.dodecahedron
    cave = Cave.new
    #hardcoding the cave here
    r1 = Room.new(1); r2 = Room.new(2); r3 = Room.new(3); r4 = Room.new(4)
    r5 = Room.new(5); r6 = Room.new(6); r7 = Room.new(7); r8 = Room.new(8)
    r9 = Room.new(9); r10 = Room.new(10); r11 = Room.new(11); r12 = Room.new(12)
    r13 = Room.new(13); r14 = Room.new(14); r15 = Room.new(15); r16 = Room.new(16)
    r17 = Room.new(17); r18 = Room.new(18); r19 = Room.new(19); r20 = Room.new(20)
    r1.connect(r2); r1.connect(r5); r1.connect(r8); r2.connect(r3); r2.connect(r10)
    r3.connect(r4); r3.connect(r12); r4.connect(r5); r4.connect(r14); r5.connect(r6)
    r6.connect(r7); r6.connect(r15); r7.connect(r8); r7.connect(r17); r8.connect(r11)
    r9.connect(r10); r9.connect(r12); r9.connect(r19); r10.connect(r11); r11.connect(r20)
    r12.connect(r13); r13.connect(r14); r13.connect(r18); r14.connect(r15); r15.connect(r16)
    r16.connect(r17); r16.connect(r18); r17.connect(r20); r18.connect(r19); r19.connect(r20)
    roomlist = [r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18,r19,r20]
    cave.setroom(roomlist)
    #return the cave that we just made
    cave
  end

  def room(roomNumber)
    #roomNumber - 1 because arrays work from 0, not 1.
    @@roomlist[roomNumber-1]
  end

  def setroom(roomlist)
    #set the cave roomlist
    @@roomlist = roomlist
  end

  def random_room()
    #get a random number between 0-19 (inclusive) and pick the room at that index
    @@roomlist[rand(0..19)]
  end

  def move(hazard, roomFrom, roomTo)
    roomTo.add(hazard)
    roomFrom.remove(hazard)
  end

  def add_hazard(hazard, numberofRooms)
    roomsAdded = 0
    while roomsAdded < Integer(numberofRooms)
      newHazardousRoom = self.random_room
      unless newHazardousRoom.has?(String(hazard))
        newHazardousRoom.add(String(hazard))
        roomsAdded += 1
      end
    end
  end

  def room_with(hazard)
    counter = 0
    returnThis = @@roomlist[counter]
    while counter < @@roomlist.length
      if @@roomlist[counter].has?(hazard) == true
        returnThis = @@roomlist[counter]
      end
      counter += 1
    end
    returnThis
  end

  def entrance()
    safeEntry = false
    newEntrance = self.random_room
    while safeEntry == false
      checkThisRoom = self.random_room
      if checkThisRoom.safe? == true
        safeEntry = true
        newEntrance = checkThisRoom
      end
    end
    newEntrance
  end


end


class Player

  def initialize
    @sensed = {}
    @encountered = {}
    @actions = {}
  end

  attr_reader :room

  def sense(hazard, &callback)
    @sensed[hazard] = callback
  end

  def encounter(hazard, &callback)
    @encountered[hazard] = callback
  end

  def action(toDo, &callback)
    @actions[toDo] = callback
  end

  def enter(room)
    @room = room

    #iterate through the possible things to encounter in a room
    @encountered.each do |hazard, action|
      return(action.call) if room.has?(hazard)
    end

  end

  def act(toDo, affectedRoom)
    @actions[toDo].call(affectedRoom)
  end

  def explore_room
    self.enter(@room)

    #Iterate through the possible things to sense
    # Callback if any of the neighbors have hazards that warrant a sense
    @sensed.each do |hazard, action|
      neighbors = @room.neighbors


      #sweep the neighbors to see if they have any hazards to report
      indexNum = 0
      while indexNum < 3
        action.call if neighbors[indexNum].has?(hazard)
        indexNum += 1
      end

    end
  end



end

