#!/usr/bin/ruby
#Miguel Pacheco
# 111453454
# CSE337
# HW2
#Checks to see if a file was given
if ARGV[0] != nil

  #Step 1: File intake
  #=====================================================================================================================
  #An error could occur if the file is not found; rescue to handle exception and alert user that filename is incorrect
  begin
  file_data = []
  File.foreach(String(ARGV[0])) {|line| file_data << line}
  #puts file_data (used to check read behavior)
  rescue
    puts "File not found, please run the script and ensure the file name is correct."
  end
  #=====================================================================================================================

  #Step 2: Sanitize the input
  #======================================================================================================================
  #Regex will only match with -c,-m,-p,-v,-w here. If true --> respective case
  if ARGV[1].match('(-|-){1}[cmpvw]{1}')

    #Step 3: Option intake
    #=====================================================================================================================
    #Note: as long as option combo is valid, then order does not matter
    #Evaluate the argument given at [1]
    case String(ARGV[1])

      #-W-----------------------------------------------------------------------------------------------------------------
    when "-w"
      #treat <pattern> as a word. Look for word in filename; return lines that contain this word
      #there are other options that you can use with
      if(String(ARGV[2])) != nil
        #Check to see if ARGV[2] is another valid command
        if ARGV[2].match('(-|-){1}[cm]{1}')
          #evaluate the argument following -w
          case String(ARGV[2])
          when "-c"
            #Return the number of lines that match the pattern
            # RETURN TYPE: INTEGER
            word = String(ARGV[3])
            matches = 0
            indexCounter = 0
            #Go through each element in the array. Ex [101 broad rd, 101 broad lane, ...]
            while indexCounter <= file_data.length
              #Turn each element into its own array (because it is a phrase)
              # Ex. "101 broad rd" --> ["101", "broad", "rd"]
              elementContents = String(file_data[indexCounter]).split
              elementContents.each do |x|
                # if any of the elements in the split phrase matches the word, matches is incremented by 1
                if x == word
                  matches += 1
                end
              end
              indexCounter += 1
            end
            puts matches
          when "-m"
            #Return the matched part of each line
            # RETURN TYPE: ARRAY[STRING]
            word = String(ARGV[3])
            matches = []
            indexCounter = 0
            #Go through each element in the array. Ex [101 broad rd, 101 broad lane, ...]
            while indexCounter <= file_data.length
              #Turn each element into its own array (because it is a phrase)
              # Ex. "101 broad rd" --> ["101", "broad", "rd"]
              elementContents = String(file_data[indexCounter]).split
              elementContents.each do |x|
                # if any of the elements in the split phrase matches the word, add x to the matches[]
                if x == word
                  matches << x
                end
              end
              indexCounter += 1
            end
            puts matches
          end
          #-------------------------------------------------------------------------------------------------------------
        else
          #Check to see if ARGV[2] is an INVALID command
          if ARGV[2].match('(-|-){1}[^cm]{1}')
            puts "Invalid combination of options"
          else
            #If ARGV[2] is NOT an INVALID command, then it must be the word we need to look for.
            #Return the lines that match the WORD given
            # RETURN TYPE: ARRAY[STRING]
            word = String(ARGV[2])
            matches = []
            indexCounter = 0
            #Iterate through file_data[] -- Ex elements: [101 broad rd, 102 etc]
            while indexCounter <= file_data.length
              #Split each element (because it is a phrase)
              # Result: "101 broad rd" --> [101, broad, rd]
              elementContents = String(file_data[indexCounter]).split
              elementContents.each do |x|
               # if any of the elements in the split phrase matches the word, the whole phrase is added to matches
                if x == word
                 matches << file_data[indexCounter]
                end
              end
              indexCounter += 1
            end
            puts matches
          end
        end
      end
      #-----------------------------------------------------------------------------------------------------------------

      #-P---------------------------------------------------------------------------------------------------------------
    when "-p"
      #treat <pattern> as regex. Look for matches in the file and return the lines that contain this.
      #there are other options that you can use  with p
      if(String(ARGV[2])) != nil
        #Check to see if ARGV[2] is another valid command
        if ARGV[2].match('(-|-){1}[cm]{1}')
          case String(ARGV[2])
          when "-c"
            #Return the number of lines that match the pattern
            # RETURN TYPE: INTEGER
            word = String(ARGV[3])
            matches = []
            file_data.each do |element|
              if element.match(word)
                matches << element
              end
            end
            puts matches.length
          when "-m"
            #Return the matched part of each line
            # RETURN TYPE: ARRAY[STRING]
            word = String(ARGV[3])
            matches = []
            indexCounter = 0
            #Go through each element in the array. Ex [101 broad rd, 101 broad lane, ...]
            while indexCounter <= file_data.length
              #Turn each element into its own array (because it is a phrase)
              # Ex. "101 broad rd" --> ["101", "broad", "rd"]
              elementContents = String(file_data[indexCounter]).split
              #There could be more than one word in a line that matches regex; capture all of these into one string
              # Ex: 101 broad road [arg: "road"] --> broad road both match "road"
              matchesinLine = ""
              elementContents.each do |x|
                if x.match(word)
                  #add each match in the line to the string
                  matchesinLine += x + " "
                end
              end
              #matches[] contains all the matches in a line that was tagged to have matched the regex
              matches << matchesinLine
              indexCounter += 1
            end
            puts matches
          end
          #-------------------------------------------------------------------------------------------------------------
        else
          #Check to see if ARGV[2] is an INVALID command
          if ARGV[2].match('(-|-){1}[^cm]{1}')
            puts "Invalid combination of options"
          else
            #If ARGV[2] is NOT an INVALID command, then it must be the word we need to look for.
            #Return the lines that match the regex
            # RETURN TYPE: ARRAY[STRING]
            word = String(ARGV[2])
            matches = []
            file_data.each do |element|
              if element.match(word)
                matches << element
              end
            end
            puts matches
          end
        end
      end
      #-----------------------------------------------------------------------------------------------------------------

      #-V-----------------------------------------------------------------------------------------------------------------
    when "-v"
      #treat <pattern> as regex. Returns all lines that do NOT match the regex.
      # there are other options you could use with v
      if(String(ARGV[2])) != nil
        #Check to see if ARGV[2] is another valid command (only C)
        if ARGV[2].match('(-|-){1}[c]{1}')
          #Return the number of lines that match the pattern
          # RETURN TYPE: INTEGER
          word = String(ARGV[3])
          matches = 0
          file_data.each do |element|
            unless element.match(word)
              matches += 1
            end
          end
          puts matches
          #-------------------------------------------------------------------------------------------------------------
        else
          #Check to see if ARGV[2] is an INVALID command
          if ARGV[2].match('(-|-){1}[^c]{1}')
            puts "Invalid combination of options"
          else
            #Return the lines that DO NOT match the regex
            # RETURN TYPE: ARRAY[STRING]
            #puts "-p, word"
            word = String(ARGV[2])
            matches = []
            file_data.each do |element|
              unless element.match(String(word))
                matches << element
              end
            end
            puts matches
          end
        end
      end
      #-----------------------------------------------------------------------------------------------------------------

      #-C-----------------------------------------------------------------------------------------------------------------
    when "-c"
      #Note that option c is a modifier for the results found in W/P/V
      if(ARGV[2]) != nil
        #Check to see if ARGV[2] is another valid command
        if ARGV[2].match('(-|-){1}[wpv]{1}')
          case ARGV[2]
          when "-w"
            #Return the number of lines that match the pattern
            # RETURN TYPE: INTEGER
            word = String(ARGV[3])
            matches = 0
            indexCounter = 0
            #Go through each element in the array. Ex [101 broad rd, 101 broad lane, ...]
            while indexCounter <= file_data.length
              #Turn each element into its own array (because it is a phrase)
              # Ex. "101 broad rd" --> ["101", "broad", "rd"]
              elementContents = String(file_data[indexCounter]).split
              elementContents.each do |x|
                # if any of the elements in the split phrase matches the word, matches is incremented by 1
                if x == word
                  matches += 1
                end
              end
              indexCounter += 1
            end
            puts matches
          when "-p"
            #Return the number of lines that match the pattern
            # RETURN TYPE: INTEGER
            word = String(ARGV[3])
            matches = []
            file_data.each do |element|
              if element.match(word)
                matches << element
              end
            end
            puts matches.length
          when "-v"
            #Return the number of lines that match the pattern
            # RETURN TYPE: INTEGER
            word = String(ARGV[3])
            matches = 0
            file_data.each do |element|
              unless element.match(word)
                matches += 1
              end
            end
            puts matches
          end
          #-------------------------------------------------------------------------------------------------------------
        else
          puts "Invalid combination of options"
        end
      else
        puts "Missing required arguments"
      end
      #-----------------------------------------------------------------------------------------------------------------

      #-M---------------------------------------------------------------------------------------------------------------
    when "-m"
      if(ARGV[2]) != nil
        if ARGV[2].match('(-|-){1}[wp]{1}')
          case ARGV[2]
          when "-w"
            #Return the matched part of each line
            # RETURN TYPE: ARRAY[STRING]
            word = String(ARGV[3])
            matches = []
            indexCounter = 0
            #Go through each element in the array. Ex [101 broad rd, 101 broad lane, ...]
            while indexCounter <= file_data.length
              #Turn each element into its own array (because it is a phrase)
              # Ex. "101 broad rd" --> ["101", "broad", "rd"]
              elementContents = String(file_data[indexCounter]).split
              elementContents.each do |x|
                # if any of the elements in the split phrase matches the word, add x to the matches[]
                if x == word
                  matches << x
                end
              end
              indexCounter += 1
            end
            puts matches

          when "-p"
            #Return the matched part of each line
            # RETURN TYPE: ARRAY[STRING]
            word = String(ARGV[3])
            matches = []
            indexCounter = 0
            #Go through each element in the array. Ex [101 broad rd, 101 broad lane, ...]
            while indexCounter <= file_data.length
              #Turn each element into its own array (because it is a phrase)
              # Ex. "101 broad rd" --> ["101", "broad", "rd"]
              elementContents = String(file_data[indexCounter]).split
              #There could be more than one word in a line that matches regex; capture all of these into one string
              # Ex: 101 broad road [arg: "road"] --> broad road both match "road"
              matchesinLine = ""
              elementContents.each do |x|
                if x.match(word)
                  #add each match in the line to the string
                  matchesinLine += x + " "
                end
              end
              #matches[] contains all the matches in a line that was tagged to have matched the regex
              matches << matchesinLine
              indexCounter += 1
            end
            puts matches
          end
          #-----------------------
        else
          puts "Invalid combination of options"
        end
      else
        puts "Missing required arguments"
      end
    end

    #=====================================================================================================================
  else
    #Input at ARGV[1] is something other than the valid options
    #Checks to see if ARGV[1] is an invalid command (a dash (-) followed by a letter)
    if ARGV[1].match('(-|-){1}[^cmpvw]{1}')
      puts ARGV[1] + " is not a valid option."
    else
      #If it turns out that ARGV[1] is not an invalid command, then it must be the regex pattern.
      #Return the lines that match the regex
      # RETURN TYPE: ARRAY[STRING]
      #puts "-p, word"
      word = String(ARGV[1])
      #puts word
      matches = []
      file_data.each do |element|
        if element.match(word)
          matches << element
        end
      end
      puts matches
    end
  end
  #======================================================================================================================

#File was not given.
else
  puts "Missing required arguments"
end